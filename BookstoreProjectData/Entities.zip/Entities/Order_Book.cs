﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookstoreProjectData.Entities
{
    
    public class Order_Book
    {
        [ForeignKey(nameof(Book))]
        public int? BookId { get; set; }
        public Book? Book { get; set; }

        [ForeignKey(nameof(Order))]

        public int? OrderId { get; set; }
        public Order? Order { get; set; }
    }
}
