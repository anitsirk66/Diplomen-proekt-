﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookstoreProjectData.Entities
{
    public class Publisher_Book
    {
        [ForeignKey(nameof(Publisher))]
        public int? PublisherId { get; set; }
        public Publisher? Publisher { get; set; }

        [ForeignKey(nameof(Book))]

        public int? BookId { get; set; }
        public Book? Book { get; set; }

        [Required]
        public string Language { get; set; } = null!;
    }
}
